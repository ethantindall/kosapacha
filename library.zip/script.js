function openMenu() {
    var element = document.getElementsByClassName("menu")[0];
    element.classList.toggle("reveal");
}
