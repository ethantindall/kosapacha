function showhide() {
    var element = document.getElementsByClassName("sidebar")[0];
    element.classList.toggle("hide");
}
