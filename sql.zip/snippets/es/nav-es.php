<ul>
    <li><a href="/index.php">Inicio</a></li>
    <li><a href="#">Sobre</a></li>
    <li><a href="/index.php/?action=contact">Contacto</a></li>
    <li><a href="#">Productos</a></li>
    <li><a href="#">Carrito</a></li>
    <li><a href="accounts/index.php/?action=login-page">Acceder</a></li>
</ul>