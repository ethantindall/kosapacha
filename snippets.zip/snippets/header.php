<div id="header-row-1">
    <span onclick="openMenu()" class="icons menu-icon"><img src="/images/menu.png" alt="Menu"></span>
    <p>KOSA<b>PACHA</b></p>   
    <form target="paypal" action="https://www.paypal.com/cgi-bin/webscr" method="post" >
        <input type="hidden" name="cmd" value="_s-xclick">
        <input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIG1QYJKoZIhvcNAQcEoIIGxjCCBsICAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCgN863svsN0S2rR0JJAw+9J6nenyI4Q9hTi6ubCjQShN2aDt6aTuUVZtC1wQ6U43ZoZb+yLFQN6/erhL2IfVMDDtbakfvZ/91fobU92rAy296oComMNv9SyYW6Yrp0Evw2GtlKiAbbtF5gdA0v6WGQMSSx6koeo330pfdOXGGPMjELMAkGBSsOAwIaBQAwUwYJKoZIhvcNAQcBMBQGCCqGSIb3DQMHBAh6QLAk8uE8Y4AwRIgCpAMGEAtbx5rOUOksiUi9JqgOXAjeiCUcRIYy93y82UVoUXt2uHeZswKnd600oIIDhzCCA4MwggLsoAMCAQICAQAwDQYJKoZIhvcNAQEFBQAwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMB4XDTA0MDIxMzEwMTMxNVoXDTM1MDIxMzEwMTMxNVowgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDBR07d/ETMS1ycjtkpkvjXZe9k+6CieLuLsPumsJ7QC1odNz3sJiCbs2wC0nLE0uLGaEtXynIgRqIddYCHx88pb5HTXv4SZeuv0Rqq4+axW9PLAAATU8w04qqjaSXgbGLP3NmohqM6bV9kZZwZLR/klDaQGo1u9uDb9lr4Yn+rBQIDAQABo4HuMIHrMB0GA1UdDgQWBBSWn3y7xm8XvVk/UtcKG+wQ1mSUazCBuwYDVR0jBIGzMIGwgBSWn3y7xm8XvVk/UtcKG+wQ1mSUa6GBlKSBkTCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb22CAQAwDAYDVR0TBAUwAwEB/zANBgkqhkiG9w0BAQUFAAOBgQCBXzpWmoBa5e9fo6ujionW1hUhPkOBakTr3YCDjbYfvJEiv/2P+IobhOGJr85+XHhN0v4gUkEDI8r2/rNk1m0GA8HKddvTjyGw/XqXa+LSTlDYkqI8OwR8GEYj4efEtcRpRYBxV8KxAW93YDWzFGvruKnnLbDAF6VR5w/cCMn5hzGCAZowggGWAgEBMIGUMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbQIBADAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMjEwMzA2MTk1MDAzWjAjBgkqhkiG9w0BCQQxFgQU/NXIhisoJnPv3HCIIJxlzqKyqPkwDQYJKoZIhvcNAQEBBQAEgYArC6BuQWbcno18EJHu4pPwiTrH/VFy+fGFKGtpFw9kFieWUCepkqn/PtgXe/nd4JX5Asw9IeXs95uOuLvoK4dn2JuW5Iv1PVOR6U627nTEz9pVdW6rIfMtH/npHoAkzkTX3/+5Mbv/dusq11FKCXmNvFMNWvOYpYOieeYK/1r/Ig==-----END PKCS7-----">
        <input type="image" src="/images/bag.png" name="submit" alt="PayPal - The safer, easier way to pay online!">
        <img alt="" border="0" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" width="1" height="1">
    </form>
</div>

<div class="menu">
    <?php 
        if($_SESSION['lang'] == 'es') { 
            echo '<ul>
                 <li><a href="/index.php">Inicio</a></li>
                 <li><a href="/index.php?action=about">Sobre</a></li>
                 <li><a href="/index.php?action=contact">Contacto</a></li>
                 <li><a href="/products/index.php">Los Productos</a></li>
                 <li><a href="/index.php?action=swap-language&language='. $_SESSION['lang'] . '">La Lengua</a></li>
                 <li><a href="/accounts/index.php/?action=login-page">Empleados</a></li>
             </ul>';}
        else { echo '<ul>
            <li><a href="/index.php">Home</a></li>
            <li><a href="/index.php?action=about">About</a></li>
            <li><a href="/index.php?action=contact">Contact</a></li>
            <li><a href="/products/index.php">Products</a></li>
            <li><a href="/index.php?action=swap-language&language='. $_SESSION['lang'] . '">Language</a></li>
            <li><a href="/accounts/index.php/?action=login-page">Employees</a></li>
        </ul>';}  ?>

</div>
