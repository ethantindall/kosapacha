<!--add backslash to front of string for AWS -->

<ul>
    <li><a href="/index.php">Home</a></li>
    <li><a href="#">About</a></li>
    <li><a href="#">Contact</a></li>
    <li><a href="/products/index.php">Products</a></li>
    <li><a href="#">Cart</a></li>
    <li><a href="/accounts/index.php/?action=login-page">Log In</a></li>
</ul>