CREATE TABLE products (
	product_id INT NOT NULL AUTO_INCREMENT,
	product_name VARCHAR(40) NOT NULL,
	product_description VARCHAR(255) NOT NULL,
	product_inventory INT NOT NULL,
	product_price FLOAT NOT NULL,
	product_expiration DATE,
    product_image VARCHAR(100),
    PRIMARY KEY (product_id)
);

CREATE TABLE employees (
	employee_id INT NOT NULL AUTO_INCREMENT,
	employee_fname VARCHAR(40) NOT NULL,
	employee_mname VARCHAR(40),
	employee_lname VARCHAR(40) NOT NULL,
	employee_notes VARCHAR(255),
	employee_max_hours FLOAT,
    employee_username VARCHAR(40) NOT NULL,
    employee_password VARCHAR(255) NOT NULL,
	PRIMARY KEY (employee_id)
);

CREATE TABLE timesheet (
	week_id INT NOT NULL AUTO_INCREMENT,
    week_date DATE NOT NULL,
    employee_id INT NOT NULL,
    weekly_max_hours FLOAT NOT NULL,
    mon_hours FLOAT NOT NULL,
    mon_notes VARCHAR(255),
	tues_hours FLOAT NOT NULL,
    tues_notes VARCHAR(255),
    wed_hours FLOAT NOT NULL,
    wed_notes VARCHAR(255),
    thurs_hours FLOAT NOT NULL,
    thurs_notes VARCHAR(255),
    fri_hours FLOAT NOT NULL,
    fri_notes VARCHAR(255),
    sat_hours FLOAT NOT NULL,
    sat_notes VARCHAR(255),
    sun_hours FLOAT NOT NULL,
    sun_notes VARCHAR(255),
    
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id),
    PRIMARY KEY (week_id)
);

create table credentials (
	credential_id INT NOT NULL AUTO_INCREMENT,
    credential_employee INT NOT NULL,
    credential_password VARCHAR(255),
    FOREIGN KEY (credential_employee) REFERENCES employees(employee_id),
    PRIMARY KEY (credential_id)
);

CREATE TABLE timesheets (
	timesheet_id INT NOT NULL AUTO_INCREMENT,
    timesheet_employee INT NOT NULL,
    timesheet_week VARCHAR(12),
    mon_time FLOAT,
    tues_time FLOAT,
    wed_time FLOAT,
    thurs_time FLOAT,
    fri_time FLOAT,
    sat_time FLOAT,
    sun_time FLOAT,
    PRIMARY KEY (timesheet_id),
	FOREIGN KEY (timesheet_employee) REFERENCES employees(employee_id)
);